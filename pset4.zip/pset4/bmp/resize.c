#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "bmp.h"

int main(int argc, char* argv[])
{
    if (argc != 4)
    {   printf("Usage: ./copy infile outfile\n");
        return 1;
    }
    int d=atoi(argv[1]);
     if (d< 1 )
    {
        printf("Factor must be in range\n");
        return 1;
    }

    char* infile = argv[2];
    char* outfile = argv[3];
    FILE* inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        printf("Could not open %s.\n", infile);
        return 2;
    }
    FILE* outptr = fopen(outfile, "w");
    if (outptr == NULL)
    {
        fclose(inptr);
        fprintf(stderr, "Could not create %s.\n", outfile);
        return 3;
    }
    BITMAPFILEHEADER bf, bf1;
    fread(&bf, sizeof(BITMAPFILEHEADER), 1, inptr);
    bf1=bf;
    
    BITMAPINFOHEADER bi, bi1;
    fread(&bi, sizeof(BITMAPINFOHEADER), 1, inptr);
    bi1=bi;

    
    if (bf.bfType != 0x4d42 || bf.bfOffBits != 54 || bi.biSize != 40 || 
        bi.biBitCount != 24 || bi.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        fprintf(stderr, "Unsupported file format.\n");
        return 4;
    }
    bi1.biWidth=bi.biWidth*d;
    bi1.biHeight=bi.biHeight*d;
    int padding = (4 - (bi.biWidth * sizeof(RGBTRIPLE)) %4) % 4;
    int newpadding = (4 - (bi1.biWidth * sizeof(RGBTRIPLE)) %4) % 4;
    
    bi1.biSizeImage = ( bi1.biWidth * sizeof(RGBTRIPLE)+newpadding) * abs(bi1.biHeight);
    bf1.bfSize = bf.bfSize - bi.biSizeImage + bi1.biSizeImage;

    fwrite(&bf1, sizeof(BITMAPFILEHEADER), 1, outptr);
    fwrite(&bi1, sizeof(BITMAPINFOHEADER), 1, outptr);
    for (int i = 0; i <abs(bi.biHeight); i++)
    {
        for (int j = 0; j < d; j++)
        {  
            for (int k = 0; k <bi.biWidth; k++)
            {
                RGBTRIPLE triple;
                fread(&triple, sizeof(RGBTRIPLE), 1, inptr);
                for (int l = 0; l < d; l++)
                    fwrite(&triple, sizeof(RGBTRIPLE), 1, outptr);
            }
            for (int l = 0; l < newpadding; l++)
                fputc(0x00, outptr);
            if(j<d-1)
             fseek(inptr,-bi.biWidth*sizeof(RGBTRIPLE),SEEK_CUR);
            
        }
        fseek(inptr, padding, SEEK_CUR);
    }
    fclose(inptr);
    fclose(outptr);
    return 0;
}
