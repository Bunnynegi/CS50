#include <stdio.h>
#include <stdint.h>

int main(void)
{   
    
    FILE* file = fopen("card.raw", "r");
    if (file == NULL)
    {
        fclose(file); 
        printf("sry but it can't be recovered \n");
        return 1;
    }
    int i = 0; 
    uint8_t buffer[512];
    char n[10]; 
   
    FILE* least = NULL; 
    
    while (!feof(file))
    {
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] == 0xe0 || buffer[3] == 0xe1))
        {
            if (least!= NULL)
            {
                fclose(least);
            }
            
            sprintf(n, "%03d.jpg",i);
            least = fopen(n, "w");
            fwrite(buffer, sizeof(buffer), 1, least);
            i++;
        }
        else if (i>0)
        {
            fwrite(buffer, sizeof(buffer), 1, least);            
        }
      
        fread(buffer, sizeof(buffer), 1, file);
        
    }
  
    fclose(file);
    return 0;
}